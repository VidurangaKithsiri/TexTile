/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.SQLException;
import java.sql.Statement;


/**
 *
 * @author Sulo
 */
public class AddgTrouser {
   
     Statement stmt;
 
     public void Trousers(String LUniqueID, String Category, String Qauntity, String Size, String Price) {

          try {
stmt = DBConnection.getStatementConnection();
stmt.executeUpdate
("INSERT INTO `girlstrousers` VALUES('"+LUniqueID+"', '"+Category+"','"+Qauntity+"', '"+Size+"', '"+Price+"')");
 } catch (SQLException e) {
 }
 
 }

  

}
    

