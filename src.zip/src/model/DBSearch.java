package model;

import java.sql.DriverManager;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class DBSearch {

    public DBSearch(Connection conn) {
    }
    private static final String URL = "jdbc:mysql://localhost:3306/dresspoint";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
   
    public ResultSet searchLogin(String usName) {
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            Statement stmt = conn.createStatement();
            String name = usName;
            // Execute the Query
            rs = stmt.executeQuery("SELECT * FROM login where username='" + name + "'");
        } catch (SQLException ex) {
            Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }
  
 public ResultSet searchTshirt() {
        ResultSet r = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            r = stmt.executeQuery("SELECT * FROM `l_t-shirt1`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return r;
    }
 public ResultSet searchTrousers() {
        ResultSet rst = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rst = stmt.executeQuery("SELECT * FROM `l_trousers`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rst;
    }
 public ResultSet searchUnderWear() {
        ResultSet rst = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rst = stmt.executeQuery("SELECT * FROM `luw`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rst;
    }
 public ResultSet searchSkirts() {
        ResultSet rst = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rst = stmt.executeQuery("SELECT * FROM `skirts`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rst;
    }
 public ResultSet searchBlouse() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `blouse`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }
 public ResultSet searchCosmatics() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `cosmatics`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }
 public ResultSet searchTShirts() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `tshirts`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }
 public ResultSet searchShorts() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `shorts1`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }
public ResultSet searchShirts() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `shirts`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }
public ResultSet searchGTrousers() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `gtrousers`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }

public ResultSet searchBCosmatics() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `bcosmatics`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;

 }
public ResultSet searchBShirts() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `bhirts`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }
public ResultSet searchBShorts() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `bshorts1`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }

        public ResultSet searchBTShirts() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `btshirts`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }
        
        public ResultSet searchBTrousers() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `btrousers`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }
        public ResultSet searchgTrousers() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `girlstrousers`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }
        public ResultSet searchgTShirts() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `girlstshirts`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }
       public ResultSet searchgCosmatics1() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `girlscosmatics`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;

 } 
        public ResultSet searchgBlouse() {
        ResultSet rslt = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rslt = stmt.executeQuery("SELECT * FROM `girlsblouse`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rslt;
    }
        public ResultSet searchbSkirts() {
        ResultSet rst = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rst = stmt.executeQuery("SELECT * FROM `girlsskirts`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rst;
    }
        public ResultSet searchgUnderWear() {
        ResultSet rst = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rst = stmt.executeQuery("SELECT * FROM `girlsluw`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rst;
    }
        public ResultSet searchBUnderWear() {
        ResultSet rst = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rst = stmt.executeQuery("SELECT * FROM `buw`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rst;
    }
        public ResultSet searchGentsUnderWear() {
        ResultSet rst = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rst = stmt.executeQuery("SELECT * FROM `guw`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rst;
    }
        public ResultSet searchEmployee() {
        ResultSet rst = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rst = stmt.executeQuery("SELECT * FROM `emp`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rst;
    }
        public class SearchCashier {
            public ResultSet searchCashier() {
        ResultSet rst = null;
        try {
            Statement stmt = DBConnection.getStatementConnection();
            rst = stmt.executeQuery("SELECT * FROM `cashier`");
        } catch (SQLException e) {
           // Logger.getLogger(DBSearch.class.getName()).log(Level.SEVERE, null, e);
        }
        return rst;
        

}
        }
}