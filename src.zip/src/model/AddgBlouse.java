/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Sulo
 */
public class AddgBlouse {
     Statement stmt;
 
     public void Blouse(String UniqueID, String Category, String Qauntity, String Size, String Price) {

          try {
stmt = DBConnection.getStatementConnection();
stmt.executeUpdate
("INSERT INTO `girlsblouse` VALUES('"+UniqueID+"', '"+Category+"','"+Qauntity+"', '"+Size+"', '"+Price+"')");
 } catch (SQLException e) {
 }
 
 }
}
