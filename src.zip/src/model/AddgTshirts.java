/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.sql.SQLException;
import java.sql.Statement;
/**
 *
 * @author Sulo
 */
public class AddgTshirts {
 
     Statement stmt;
 
    public void Tshirt(String UniqueID, String Category, String TShirtsQauntity, String TShirtSize ,String Price) {

          try {
stmt = DBConnection.getStatementConnection();
stmt.executeUpdate
("INSERT INTO `girlstshirt1` VALUES('"+UniqueID+"', '"+Category+"','"+TShirtsQauntity+"', '"+TShirtSize+"', '"+Price+"')");
 } catch (SQLException e) {
 }
 
 }
    

}
