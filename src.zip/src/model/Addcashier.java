/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
/**
 *
 * @author Sulo
 */
public class Addcashier {

 Statement stmt;
 
     public void cashier(String ID, String Price, String Qauntity, String Total,String Amount, String Balance) {

          try {
stmt = DBConnection.getStatementConnection();
stmt.executeUpdate
("INSERT INTO `cashier` VALUES('"+ID+"', '"+Price+"','"+Qauntity+"', '"+Total+"', '"+Amount+"', '"+Balance+"')");
 } catch (SQLException e) {
 }
 
 }
}

