/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Sulo
 */
public class GentsUnderwearController {
     private static final List<String[]> UnderWear = new ArrayList<>();
 
    /**
     *
     * @param UniqueID
     * @param Category
     * @param Qauntity
     * @param Size
     * @param Price */
    public static void UnderWear(String UniqueID, String Category, String Qauntity, String Size, String Price) 
 { 
     
     UnderWear.add(new String[]{UniqueID, Category, Qauntity, Size, Price});
     new model.AddGentsUnderwear().UnderWear(UniqueID, Category, Qauntity, Size, Price);
 
     JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull",JOptionPane.INFORMATION_MESSAGE);
} 
      public static List<String[]> getUnderWear() {
        return UnderWear;
}  
}
