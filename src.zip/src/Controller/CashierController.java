/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import view.cashier;
/**
 *
 * @author Sulo
 */
public class CashierController {

    private static final List<String[]> cashier = new ArrayList<>();
 
    /**
     * @param ID
     * @param Balance
     * @param Qauntity
     * @param Total
     * @param Price
     * @param Amount */
    public static void cashier(String ID, String Price, String Qauntity, String Total,String Amount, String Balance) 
 { 
        
     
    cashier.add(new String[]{ID, Price, Qauntity,Total,Amount, Balance});
     new model.Addcashier().cashier(ID, Price, Qauntity,Total,Amount, Balance);
 
     JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull",JOptionPane.INFORMATION_MESSAGE);
} 
      public static List<String[]> getCashier() {
        return cashier;
}
}


