/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import model.DBSearch;
 import javax.swing.JOptionPane;
 import java.util.ArrayList;
 import java.util.List;
/**
 *
 * @author Sulo
 */
public class gTshirtController {
    

     private static final List<String[]> Tshirt = new ArrayList<>();
 
    /**
     *
     * @param UniqueID
     * @param Category
     * @param TShirtsQauntity
     * @param TShirtSize
     * @param Price */
    public static void Tshirt(String UniqueID, String Category, String TShirtsQauntity, String TShirtSize, String Price) 
 { 
     
     Tshirt.add(new String[]{UniqueID, Category, TShirtsQauntity, TShirtSize, Price});
     new model.AddgTshirts().Tshirt(UniqueID, Category, TShirtsQauntity, TShirtSize, Price);
 
     JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull",JOptionPane.INFORMATION_MESSAGE);
} 
      public static List<String[]> getTshirt() {
        return Tshirt;
}  
}
    
   

   

       
