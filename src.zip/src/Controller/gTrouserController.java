/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Sulo
 */
public class gTrouserController {
    
     private static final List<String[]> Trousers = new ArrayList<>();
 
    /**
     *
     * @param LUniqueID
     * @param Category
     * @param TShirtsQauntity
     * @param TShirtSize
     * @param Price */
    public static void Trousers(String LUniqueID, String Category, String TShirtsQauntity, String TShirtSize, String Price) 
 { 
     
     Trousers.add(new String[]{LUniqueID, Category, TShirtsQauntity, TShirtSize, Price});
     new model.AddgTrouser().Trousers(LUniqueID, Category, TShirtsQauntity, TShirtSize, Price);
 
     JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull",JOptionPane.INFORMATION_MESSAGE);
} 
      public static List<String[]> getTrousers() {
        return Trousers;
}  
}
