/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Sulo
 */
public class GTrousersController {
    private static final List<String[]> GTrousers = new ArrayList<>();
 
    /**
     *
     * @param LUniqueID
     * @param Category
     * @param Qauntity
     * @param Size
     * @param Price */
    public static void GTrousers(String UniqueID, String Category, String Qauntity, String Size, String Price) 
 { 
     
     GTrousers.add(new String[]{UniqueID, Category, Qauntity, Size, Price});
     new model.AddGTrousers().GTrousers(UniqueID, Category, Qauntity, Size, Price);
 
     JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull",JOptionPane.INFORMATION_MESSAGE);
} 
      public static List<String[]> getGTrousers() {
        return GTrousers;
}  
}
