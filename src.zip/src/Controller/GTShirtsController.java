/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import Gents.TShirts;
/**
 *
 * @author Sulo
 */
public class GTShirtsController {
     private static final List<String[]> Tshirts = new ArrayList<>();
 
    /**
     *
     * @param UniqueID
     * @param Category
     * @param Qauntity
     * @param Size
     * @param Price */
    public static void TShirts(String UniqueID, String Category, String Qauntity, String Size, String Price) 
 { 
     
     Tshirts.add(new String[]{UniqueID, Category, Qauntity, Size, Price});
     new model.AddGentsTShirts().Tshirts(UniqueID, Category, Qauntity, Size, Price);
 
     JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull",JOptionPane.INFORMATION_MESSAGE);
} 
      public static List<String[]> getTshirts() {
        return Tshirts;
}   

   
   
}
