/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Sulo
 */
public class GShortsController {

   

     private static final List<String[]> Shorts = new ArrayList<>();
 
    /**
     *
     * @param UniqueID
     * @param Category
     * @param Qauntity
     * @param Size
     * @param Price */
    public static void Shorts(String UniqueID, String Category, String Qauntity, String Size, String Price) 
 { 
     
    Shorts.add(new String[]{UniqueID, Category, Qauntity, Size, Price});
     new model.AddShorts().Shorts(UniqueID, Category, Qauntity, Size, Price);
 
     JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull",JOptionPane.INFORMATION_MESSAGE);
} 
      public static List<String[]> getShorts() {
        return Shorts;
}    

}
  

