/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Sulo
 */
public class GCosmaticsController {
     private static final List<String[]> GCosmatics = new ArrayList<>();
 
    /**
     *
     * @param UniqueID
     * @param Category
     * @param Qauntity
     * @param Size
     * @param Price */
    public static void GCosmatics(String UniqueID, String Category, String Qauntity, String Size, String Price) 
 { 
     
    GCosmatics.add(new String[]{UniqueID, Category, Qauntity, Size, Price});
     new model.AddGCosmatics().GCosmatics(UniqueID, Category, Qauntity, Size, Price);
 
     JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull",JOptionPane.INFORMATION_MESSAGE);
} 
      public static List<String[]> getCosmatics() {
        return GCosmatics;
}    
}
