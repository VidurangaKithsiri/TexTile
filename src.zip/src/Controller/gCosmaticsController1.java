/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Sulo
 */
public class gCosmaticsController1 {
     private static final List<String[]> Cosmatics = new ArrayList<>();
 
    /**
     *
     * @param UniqueID
     * @param Category
     * @param Qauntity
     * @param Size
     * @param Price */
    public static void Cosmatics(String UniqueID, String Category, String Qauntity, String Size, String Price) 
 { 
     
    Cosmatics.add(new String[]{UniqueID, Category, Qauntity, Size, Price});
     new model.AddgCosmatics1().Cosmatics(UniqueID, Category, Qauntity, Size, Price);
 
     JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull",JOptionPane.INFORMATION_MESSAGE);
} 
      public static List<String[]> getCosmatics() {
        return Cosmatics;
}    

}
